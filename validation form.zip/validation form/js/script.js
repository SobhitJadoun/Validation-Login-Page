// const btn = document.getElementById('id');
// const username = document.getElementById('username')
// const email = document.getElementById('email')
// const pass = document.getElementById('pass')
// const vpass = document.getElementById('vpass')

// let user = undefined;
// let em = undefined;
// let pas = undefined;
// let vpas = undefined;

// btn.addEventListener('click', e => {
//     checkData();
// })
// function checkData(params) {
//     const username = username.value.trim();
//     const emailValue = email.value.trim();
//     const passwordValue = pass.value.trim();
//     const vpasswordValue = vpass.value.trim();


//     if (usernameValue == '') {
//         setError(username, "username cannot be blank");
//         user = false;
//     } else {
//         setNoerror(username)
//         user = true
//     }

//     if (emailValue == '') {
//         setError(email, "email cannot be blank");
//         em = false;
//     }else if(!rEmail(emailvalue)){
//         setError(email,"email is not valid")
//     } 
//     else {
//         setNoerror(username)
//         em = true
//     }
// }